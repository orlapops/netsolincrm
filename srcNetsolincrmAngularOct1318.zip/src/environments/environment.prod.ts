export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyDz_d6qIjTAN_-lU8neFAKQIbnmMkqpKoU",
    authDomain: "catalogo-43ff6.firebaseapp.com",
    databaseURL: "https://catalogo-43ff6.firebaseio.com",
    projectId: "catalogo-43ff6",
    storageBucket: "catalogo-43ff6.appspot.com",
    messagingSenderId: "254647114546"
    }

};
