import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nopagesfound',
  templateUrl: './nopagesfound.component.html',
  styles: []
})
export class NopagesfoundComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
